(() => {
  const $ = (s, r = document) => r.querySelector(s);
  const $$ = (s, r = document) => [...r.querySelectorAll(s)];
  const reduce = matchMedia('(prefers-reduced-motion: reduce)').matches;

  /* ---------- hero: whole heading rises together, blur heaviest at the bottom ---------- */
  requestAnimationFrame(() => requestAnimationFrame(() => {
    $('#heroIntro').classList.add('in'); $('#heroTitle').classList.add('in'); $('#heroSub').classList.add('in'); $('#heroPrev').classList.add('in');
  }));

  /* ---------- hero proof: founders rail <-> previously worked with (founders 15s, previously 5s) ---------- */
  (function () {
    const A = $('#panelFounders'), B = $('#panelPrev');
    if (!A || !B || reduce) return;
    let showA = false;
    const set = (el, on) => { el.classList.toggle('on', on); el.setAttribute('aria-hidden', String(!on)); };
    setTimeout(function swap() {
      showA = !showA;
      set(A, showA); set(B, !showA);
      setTimeout(swap, showA ? 15000 : 5000);
    }, 6500);
  })();

  /* ---------- reveal on load / scroll ---------- */
  const io = new IntersectionObserver(es => es.forEach(e => {
    if (e.isIntersecting) { e.target.classList.add('in'); io.unobserve(e.target); }
  }), { threshold: .12, rootMargin: '0px 0px -6% 0px' });
  requestAnimationFrame(() => requestAnimationFrame(() => {
    $$('.reveal').forEach(el => io.observe(el));
  }));

  /* ---------- mobile nav ---------- */
  const burger = $('#burger'), links = $('#navLinks');
  burger.addEventListener('click', () => {
    const open = links.classList.toggle('open');
    burger.setAttribute('aria-expanded', open);
  });
  links.addEventListener('click', e => { if (e.target.tagName === 'A') { links.classList.remove('open'); burger.setAttribute('aria-expanded', false); } });

  /* ---------- Apple-style icon glare / tilt ---------- */
  $$('button.app-icon').forEach(el => {
    el.addEventListener('pointermove', e => {
      const r = el.getBoundingClientRect();
      const x = (e.clientX - r.left) / r.width, y = (e.clientY - r.top) / r.height;
      el.style.setProperty('--mx', x * 100 + '%'); el.style.setProperty('--my', y * 100 + '%');
      el.style.setProperty('--ry', ((x - .5) * 14) + 'deg'); el.style.setProperty('--rx', ((.5 - y) * 14) + 'deg');
    });
    el.addEventListener('pointerleave', () => { el.style.setProperty('--rx', '0deg'); el.style.setProperty('--ry', '0deg'); });
  });

  /* ---------- hover cards ---------- */
  const DATA = {
    swiggy: {
      title: 'Swiggy', dates: 'Dec 2023 – Present',
      text: 'Designing 0→1 products at Swiggy — an industry-first loyalty program and a fresh take on the digital menu.',
      drove: ['DineCash — a loyalty program to increase the frequency of transactions', 'Digital Menu — taking the menu off paper, 0→1'],
      shots: [['assets/dinecash.webp', 'DineCash']]
    },
    cultfit: {
      title: 'Cult.fit', dates: 'Oct 2022 – Oct 2023',
      text: 'Made buying gym access simpler and more flexible for members.',
      drove: ['Revamped the purchase flow — buy a single gym access or all gym access'],
      shots: [['assets/cultfit-thumb.webp', 'Cult.fit purchase flow']]
    },
    dunzo: {
      title: 'Dunzo', dates: 'Nov 2020 – Oct 2022',
      text: 'Helped merchants receive and process incoming orders with less friction.',
      drove: ['Merchant order processing — accept, prepare and hand off orders'],
      shots: [['assets/dunzo-thumb.webp', 'Dunzo order processing']]
    }
  };
  const hc = $('#hovercard'), shots = $('#hcShots'), hcTitle = $('#hcTitle'), hcText = $('#hcText'), hcDates = $('#hcDates');
  let hideT, current = null;

  function place(anchor) {
    const r = anchor.getBoundingClientRect();
    const w = hc.offsetWidth, h = hc.offsetHeight, m = 12;
    let left = r.left + r.width / 2 - w / 2;
    left = Math.max(m, Math.min(left, innerWidth - w - m));
    let top = r.bottom + 14;
    if (top + h > innerHeight - m) top = Math.max(m, r.top - h - 14);
    hc.style.left = left + 'px'; hc.style.top = top + 'px';
    hc.style.transformOrigin = `${r.left + r.width / 2 - left}px ${top > r.top ? 'top' : 'bottom'}`;
  }
  function show(anchor) {
    clearTimeout(hideT);
    const d = DATA[anchor.dataset.card]; if (!d) return;
    if (current !== anchor) {
      hcTitle.textContent = d.title; hcDates.textContent = d.dates; hcText.textContent = d.text;
      shots.innerHTML = '';
      d.shots.forEach(([src, label]) => {
        const s = document.createElement('div'); s.className = 'shot'; s.dataset.label = label;
        const i = new Image(); i.src = src; i.alt = label; i.onerror = () => s.classList.add('missing');
        s.append(i); shots.append(s);
      });
      current = anchor;
    }
    hc.classList.add('show'); hc.setAttribute('aria-hidden', 'false'); place(anchor);
  }
  function hide(delay = 120) {
    hideT = setTimeout(() => { hc.classList.remove('show'); hc.setAttribute('aria-hidden', 'true'); current = null; }, delay);
  }
  $$('[data-card]').forEach(a => {
    a.addEventListener('mouseenter', () => show(a));
    a.addEventListener('mouseleave', () => hide());
    a.addEventListener('focus', () => show(a));
    a.addEventListener('blur', () => hide());
    a.addEventListener('click', e => { e.preventDefault(); current === a && hc.classList.contains('show') ? hide(0) : show(a); });
  });
  hc.addEventListener('mouseenter', () => clearTimeout(hideT));
  hc.addEventListener('mouseleave', () => hide());
  document.addEventListener('click', e => { if (!e.target.closest('[data-card]') && !e.target.closest('#hovercard')) hide(0); });
  addEventListener('scroll', () => hc.classList.contains('show') && current && place(current), { passive: true });
  addEventListener('resize', () => hc.classList.contains('show') && current && place(current));

  /* ---------- active nav link ---------- */
  const secs = ['work', 'beyond', 'wall'].map(id => document.getElementById(id));
  const navA = $$('.nav-links a');
  const spy = new IntersectionObserver(es => es.forEach(e => {
    if (e.isIntersecting) navA.forEach(a => a.classList.toggle('active', a.getAttribute('href') === '#' + e.target.id));
  }), { rootMargin: '-45% 0px -50% 0px' });
  secs.forEach(s => s && spy.observe(s));

  /* ---------- RESUME overlay ---------- */
  const resume = $('#resume');
  function openResume() {
        resume.classList.add('open'); resume.setAttribute('aria-hidden', 'false');
    document.body.classList.add('resume-open'); resume.scrollTop = 0;
    hc.classList.remove('show');
    if (location.hash !== '#resume') history.replaceState(null, '', '#resume');
  }
  function closeResume() {
    resume.classList.remove('open'); resume.setAttribute('aria-hidden', 'true');
    document.body.classList.remove('resume-open');
    if (location.hash === '#resume') history.replaceState(null, '', location.pathname + location.search);
  }
  window.__openResume = openResume;
  $$('[data-resume]').forEach(a => a.addEventListener('click', e => { e.preventDefault(); links.classList.remove('open'); burger.setAttribute('aria-expanded', false); openResume(); }));
  $('#resumeClose').addEventListener('click', closeResume);
  addEventListener('keydown', e => { if (e.key === 'Escape' && resume.classList.contains('open')) closeResume(); });
  if (location.hash === '#resume') openResume();

  // PDF download: in the artifact viewer use the downloads capability, elsewhere the plain link works
  const dl = $('.resume-bar a[download]');
  dl.addEventListener('click', async e => {
    if (!(window.claude && window.claude.use)) return;
    e.preventDefault();
    try {
      const d = await window.claude.use('downloads');
      if (!d) { location.href = dl.getAttribute('href'); return; }
      const res = await fetch(dl.getAttribute('href'));
      const buf = await res.arrayBuffer();
      await d.save({ filename: 'Elaya-Resume.pdf', data: new Blob([buf], { type: 'application/pdf' }) });
    } catch (err) { console.warn('download not completed', err); }
  });

  /* ---------- WHO AM I: typewriter + photo rail ---------- */
  const TOPICS = [
    { text: 'riding bikes',     slug: 'bikes',     widths: [300, 420, 300, 360, 300, 440] },
    { text: 'playing badminton', slug: 'badminton', widths: [360, 300, 440, 300, 380, 300] }
  ];
  const swap = $('#swap'), track = $('#track'), typeEl = $('#typeText');
  const sleep = ms => new Promise(r => setTimeout(r, ms));
  function buildTiles(t) {
    const set = t.widths.map((w, i) => {
      const d = document.createElement('div'); d.className = 'tile'; d.style.width = `clamp(${Math.round(w * .62)}px,${(w / 14.4).toFixed(1)}vw,${w}px)`;
      const im = new Image(); im.src = `assets/${t.slug}-${i + 1}.jpg`; im.alt = `${t.text} ${i + 1}`;
      im.onerror = () => d.classList.add('missing');
      const ph = document.createElement('div'); ph.className = 'ph2'; ph.textContent = `Add ${t.slug} photo ${i + 1}`;
      d.append(im, ph); return d;
    });
    track.innerHTML = '';
    [...set, ...set.map(n => n.cloneNode(true))].forEach(n => {
      // clones lose handlers; re-attach error fallback
      const im = n.querySelector('img'); if (im) im.onerror = () => n.classList.add('missing');
      track.append(n);
    });
  }
  async function swapTiles(t, first) {
    if (!first && !reduce) { swap.classList.add('out'); await sleep(550); }
    swap.classList.remove('out'); swap.classList.add('pre');
    buildTiles(t);
    void swap.offsetWidth; swap.classList.remove('pre');
  }
  async function typeLoop() {
    let n = 0;
    for (;;) {
      const t = TOPICS[n % TOPICS.length];
      swapTiles(t, n === 0);
      for (let i = 1; i <= t.text.length; i++) { typeEl.textContent = t.text.slice(0, i); await sleep(70); }
      await sleep(4200);
      for (let i = t.text.length - 1; i >= 0; i--) { typeEl.textContent = t.text.slice(0, i); await sleep(32); }
      await sleep(350); n++;
    }
  }
  if (typeEl) {
    if (reduce) { typeEl.textContent = TOPICS[0].text; buildTiles(TOPICS[0]); }
    else {
      const aboutIO = new IntersectionObserver(es => { if (es[0].isIntersecting) { aboutIO.disconnect(); typeLoop(); } }, { threshold: .25 });
      aboutIO.observe($('#about'));
    }
  }

  /* ---------- PENCIL: cursor + real drawing ---------- */
  const fine = matchMedia('(hover:hover) and (pointer:fine)').matches;
  if (!fine) return;

  const canvas = $('#ink'), ctx = canvas.getContext('2d');
  const pencil = $('#pencil');
  const strokes = [];                 // {pts:[[x,y,w]], t:lastPointTime, done:bool}
  const HOLD = 500, FADE = 1000;     // ms visible, ms to dissolve
  let drawing = false, cur = null, raf = 0, dpr = Math.min(devicePixelRatio || 1, 2);

  function docH() { const pg = document.getElementById('page'), f = document.getElementById('contact'); return Math.max(innerHeight, pg ? pg.offsetHeight + (f ? f.offsetHeight - 40 : 0) : document.documentElement.scrollHeight); }
  function sizeCanvas() {
    const w = document.documentElement.clientWidth;
    const h = docH();
    canvas.style.width = w + 'px'; canvas.style.height = h + 'px';
    canvas.width = w * dpr; canvas.height = h * dpr;
    ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
  }
  // one continuous smoothed path per stroke: ends exactly at the pencil tip, no beading at joins
  function paintStroke(s) {
    const pts = s.pts;
    if (pts.length < 2) { if (s.hl) return; const p = pts[0]; ctx.fillStyle = s.lite ? 'rgba(255,255,255,.9)' : 'rgba(26,26,26,.85)'; ctx.beginPath(); ctx.arc(p[0], p[1], 1.3, 0, 7); ctx.fill(); return; }
    ctx.lineCap = 'round'; ctx.lineJoin = 'round';
    const path = new Path2D();
    path.moveTo(pts[0][0], pts[0][1]);
    for (let i = 1; i < pts.length - 1; i++) {
      const mx = (pts[i][0] + pts[i + 1][0]) / 2, my = (pts[i][1] + pts[i + 1][1]) / 2;
      path.quadraticCurveTo(pts[i][0], pts[i][1], mx, my);
    }
    const l = pts[pts.length - 1]; path.lineTo(l[0], l[1]);
    if (s.hl) { ctx.lineCap = 'butt'; ctx.strokeStyle = 'rgba(255,221,45,.3)'; ctx.lineWidth = 18; ctx.stroke(path); return; }
    ctx.strokeStyle = s.lite ? 'rgba(255,255,255,.22)' : 'rgba(30,30,30,.22)'; ctx.lineWidth = 3.6; ctx.stroke(path);   // soft graphite halo
    ctx.strokeStyle = s.lite ? 'rgba(255,255,255,.95)' : 'rgba(26,26,26,.88)'; ctx.lineWidth = 1.9; ctx.stroke(path);   // sharp core
  }
  // strokes blur out in place (no movement) once the hold time has passed
  const FADE_MS = 450;
  function frame(now) {
    ctx.clearRect(0, 0, canvas.width, canvas.height);
    for (let i = strokes.length - 1; i >= 0; i--) {
      const s = strokes[i];
      const live = s === cur && drawing;
      const p = live ? 0 : Math.min(1, Math.max(0, (now - s.t - HOLD) / FADE_MS));
      if (p >= 1) { strokes.splice(i, 1); continue; }
      ctx.save();
      if (p > 0) {
        ctx.globalAlpha = 1 - p;
        if ('filter' in ctx) ctx.filter = `blur(${(p * 8).toFixed(1)}px)`;
      }
      paintStroke(s);
      ctx.restore();
    }
    raf = strokes.length ? requestAnimationFrame(frame) : 0;
  }
  const kick = () => { if (!raf) raf = requestAnimationFrame(frame); };
  sizeCanvas();
  addEventListener('resize', sizeCanvas);
  new ResizeObserver(() => { const h = docH(); if (Math.abs(h - canvas.height / dpr) > 4) sizeCanvas(); }).observe(document.body);

  // arrow over anything clickable / navigational, pencil elsewhere
  const CLICKY = '.post,.case,.pin,a,button,input,textarea,select,.nav,.nav-links,.card,.hovercard,[data-card]';
  let lx = 0, ly = 0, lt = 0, lw = 2.2;
  const TEXT = 'h1,h2,h3,h4,p,li,.eyebrow,.type-line,.about-lead,.prev-cap,.hero-intro,small,b,strong';
  const isText = t => !!(t && t.closest && t.closest(TEXT) && !t.closest(CLICKY));

  addEventListener('pointermove', e => {
    pencil.classList.add('on');
    pencil.style.transform = `translate(${e.clientX}px,${e.clientY}px)`;
    pencil.classList.toggle('lite', !!(e.target.closest && e.target.closest('#contact')));
    pencil.classList.toggle('pointer', !!(e.target.closest && e.target.closest(CLICKY)));
    if (!drawing) return;
    const evs = e.getCoalescedEvents ? e.getCoalescedEvents() : [e];
    for (const ev of (evs.length ? evs : [e])) {
      const x = ev.clientX + scrollX, y = ev.clientY + scrollY;
      const last = cur.pts[cur.pts.length - 1];
      if (Math.hypot(x - last[0], y - last[1]) < 1.2) continue;   // ignore jitter
      cur.pts.push([x, y]);
    }
    cur.t = performance.now();
  });
  addEventListener('pointerdown', e => {
    if (document.body.classList.contains('resume-open') || document.body.classList.contains('case-open')) return;
    if (e.button !== 0 || (e.target.closest && e.target.closest(CLICKY))) return;
    e.preventDefault();
    drawing = true; pencil.classList.add('down');
    const x = e.clientX + scrollX, y = e.clientY + scrollY;
    lx = x; ly = y; lt = performance.now(); lw = 2.2;
    cur = { pts: [[x, y]], t: lt, hl: false, lite: !!(document.elementFromPoint(e.clientX, e.clientY)?.closest('#contact')) }; strokes.push(cur); kick();
  });
  const end = () => { if (cur) cur.t = performance.now(); drawing = false; pencil.classList.remove('down'); kick(); };
  addEventListener('pointerup', end); addEventListener('pointercancel', end);
  document.addEventListener('mouseleave', () => pencil.classList.remove('on'));
  document.addEventListener('mouseenter', () => pencil.classList.add('on'));
  document.addEventListener('selectstart', e => { if (drawing) e.preventDefault(); });
})();

/* ---------- CASE STUDIES ---------- */
(function(){
  const $=s=>document.querySelector(s), box=$('#case'), inn=$('#caseIn'), pin=$('#pin');
  if(!window.CASES||!box) return;
  const b64=s=>Uint8Array.from(atob(s),c=>c.charCodeAt(0));
  const esc=s=>String(s).replace(/&/g,'&amp;').replace(/</g,'&lt;');
  let cur=null, unlocked=null;
  function open(k){
    const c=CASES.items[k]; cur=k;
    inn.innerHTML='<button class="cs-back" id="csBack"><span aria-hidden="true">←</span> Go back</button><div class="cs-brand"><img src="'+c.logo+'" alt="">'+esc(c.brand)+'</div><h1>'+esc(c.title)+'</h1><p class="cs-lead">'+esc(c.lead)+'</p>'
     +'<div class="cs-meta">'+c.meta.map(m=>'<div><span>'+esc(m[0])+'</span><b>'+esc(m[1])+'</b></div>').join('')+'</div>'
     +'<div class="cs-cols">'+c.cols.map(x=>'<div class="cs-col"><h3>'+esc(x[0])+'</h3><p>'+esc(x[1])+'</p></div>').join('')+'</div>'
     +(c.stats.length?'<div class="cs-stats">'+c.stats.map(x=>'<div><b>'+esc(x[0])+'</b><span>'+esc(x[1])+'</span></div>').join('')+'</div>':'')
     +'<div class="cs-more" id="csMore"><button class="btn-more" id="csBtn">Read full case study <span aria-hidden="true">→</span></button></div><div class="cs-locked" id="csLocked"></div>';
    $('#csBack').onclick=close; $('#csBtn').onclick=()=>unlocked?reveal(k):askPin();
    if(unlocked) reveal(k);
    document.body.classList.add('case-open'); box.scrollTop=0; box.classList.add('on'); box.setAttribute('aria-hidden','false');
  }
  function close(){box.classList.remove('on');box.setAttribute('aria-hidden','true');document.body.classList.remove('case-open');closePin();}
  async function reveal(k){
    const c=CASES.items[k];
    try{
      const pt=await crypto.subtle.decrypt({name:'AES-GCM',iv:b64(c.iv)},unlocked,b64(c.ct));
      const url=new TextDecoder().decode(pt);
      const w=window.open(url,'_blank','noopener');
      if(!w){$('#csLocked').innerHTML='<div class="cs-proto"><div><b>Unlocked</b><span>Your browser blocked the pop-up. Use the button to open it.</span></div><a class="btn-more" href="'+url+'" target="_blank" rel="noopener">View prototype slides \u2197</a></div>';$('#csMore').style.display='none';}
    }catch(e){unlocked=null;}
  }
  const ins=[...pin.querySelectorAll('input')], err=$('#pinErr'), dots=$('#pinDots');
  function askPin(){pin.classList.add('on');pin.setAttribute('aria-hidden','false');ins.forEach(i=>i.value='');err.textContent='';setTimeout(()=>ins[0].focus(),50);}
  function closePin(){pin.classList.remove('on');pin.setAttribute('aria-hidden','true');}
  async function tryPin(code){
    try{
      const km=await crypto.subtle.importKey('raw',new TextEncoder().encode(code),'PBKDF2',false,['deriveKey']);
      const key=await crypto.subtle.deriveKey({name:'PBKDF2',salt:b64(CASES.salt),iterations:200000,hash:'SHA-256'},km,{name:'AES-GCM',length:256},false,['decrypt']);
      unlocked=key; await crypto.subtle.decrypt({name:'AES-GCM',iv:b64(CASES.items[cur].iv)},key,b64(CASES.items[cur].ct));
      closePin(); reveal(cur);
    }catch(e){
      unlocked=null; err.textContent='Wrong password. Try again.'; dots.classList.remove('bad'); void dots.offsetWidth; dots.classList.add('bad');
      ins.forEach(i=>i.value=''); ins[0].focus();
    }
  }
  ins.forEach((el,i)=>{
    el.addEventListener('input',()=>{el.value=el.value.replace(/\D/g,'').slice(-1); if(el.value&&i<5) ins[i+1].focus(); if(ins.every(x=>x.value)) tryPin(ins.map(x=>x.value).join(''));});
    el.addEventListener('keydown',e=>{if(e.key==='Backspace'&&!el.value&&i>0) ins[i-1].focus();});
    el.addEventListener('paste',e=>{const t=(e.clipboardData.getData('text')||'').replace(/\D/g,'').slice(0,6); if(t.length===6){e.preventDefault();t.split('').forEach((d,j)=>ins[j].value=d);tryPin(t);}});
  });
  $('#pinForm').addEventListener('submit',e=>e.preventDefault());
  $('#pinCancel').onclick=closePin; pin.addEventListener('click',e=>{if(e.target===pin)closePin();});
  const LINKEDIN='https://www.linkedin.com/in/elayamanikandan-k-08037a1a5/';
  const toast=$('#toast'); let tt;
  $('#mailLink').addEventListener('click',()=>{
    const m='elayamanikandank26@gmail.com';
    try{navigator.clipboard.writeText(m);}catch(e){const t=document.createElement('textarea');t.value=m;document.body.appendChild(t);t.select();try{document.execCommand('copy');}catch(_){}t.remove();}
    toast.textContent='Email copied to clipboard'; toast.classList.add('on'); clearTimeout(tt); tt=setTimeout(()=>toast.classList.remove('on'),2200);
  });
  addEventListener('keydown',e=>{if(e.key==='Escape'){pin.classList.contains('on')?closePin():box.classList.contains('on')&&close();}});
  document.querySelectorAll('[data-case]').forEach(a=>{a.addEventListener('click',()=>open(a.dataset.case));a.addEventListener('keydown',e=>{if(e.key==='Enter')open(a.dataset.case);});});
})();

/* LinkedIn embeds are blocked inside the artifact viewer: show link cards there, real embeds elsewhere */
(function(){
  const b = document.getElementById('beyond');
  if (b && window.claude && window.claude.use) b.classList.add('no-embed');
})();

/* LinkedIn-style posts: play/pause video, autoplay in view */
(function(){
  document.querySelectorAll('.li-post, .x-post').forEach(card=>{
    const open=()=>window.open(card.dataset.href,'_blank','noopener');
    card.addEventListener('click',e=>{ if(e.target.closest('a')) return; open(); });
    card.addEventListener('keydown',e=>{ if(e.key==='Enter') open(); });
    const v=card.querySelector('video'), play=card.querySelector('.li-play'); if(!v) return;
    const toggle=()=>{ if(v.paused){v.play().catch(()=>{});}else{v.pause();} };
    v.addEventListener('play',()=>play.classList.add('hide')); v.addEventListener('pause',()=>play.classList.remove('hide'));
    new IntersectionObserver(es=>es.forEach(e=>{ if(e.isIntersecting){v.play().catch(()=>{});}else{v.pause();} }),{threshold:.6}).observe(v);
  });
})();

/* footer: curtain + scroll-linked letters, email copy, placeholder links */
(function(){
  const page=document.getElementById('page'), foot=document.getElementById('contact'), w=document.getElementById('footWord');
  const L=w?[...w.children]:[];
  const OVER=40; let lastP=0;
  function size(){ if(page&&foot) page.style.setProperty('--footH',(foot.offsetHeight-OVER)+'px'); }
  const clamp=(v,a,b)=>Math.min(b,Math.max(a,v)), ease=t=>1-Math.pow(1-t,3);
  const grid=document.querySelector('.foot-grid'); let target=0, cur=0, raf=0, bt=0;
  function paint(){

  }
  function loop(){ cur+=(target-cur)*0.14; if(Math.abs(target-cur)<.002) cur=target; paint(); raf=cur===target?0:requestAnimationFrame(loop); }
  function tick(){
    if(!page||!foot) return;
    const fh=foot.offsetHeight-OVER, vis=clamp(innerHeight-page.getBoundingClientRect().bottom,0,fh), p=fh?vis/fh:0, dp=p-lastP; lastP=p;
    if(w){
      if(dp>0.002 && p>.3 && !w.classList.contains('in')){ w.classList.add('in'); w.classList.remove('out'); }
      else if((dp<-0.004 && p<.97 || p<.1) && w.classList.contains('in')){ w.classList.remove('in'); w.classList.add('out'); }
    }
  }
  if(foot&&window.ResizeObserver) new ResizeObserver(()=>{size();tick();}).observe(foot);
  size(); tick(); addEventListener('resize',()=>{size();tick();}); addEventListener('scroll',tick,{passive:true}); addEventListener('load',()=>{size();tick();});
  document.querySelectorAll('.soc img[data-color]').forEach(img=>{ const a=img.closest('a'), g=img.src, c=img.dataset.color; const pre=new Image(); pre.src=c;
    a.addEventListener('mouseenter',()=>img.src=c); a.addEventListener('mouseleave',()=>img.src=g); });
  document.querySelectorAll('.soc[data-soon]').forEach(a=>a.addEventListener('click',e=>e.preventDefault()));
  const m=document.getElementById('footMail'), t=document.getElementById('toast');
  if(m&&t) m.addEventListener('click',()=>{
    try{navigator.clipboard.writeText('elayamanikandank26@gmail.com');}catch(e){}
    t.textContent='Email copied to clipboard'; t.classList.add('on'); setTimeout(()=>t.classList.remove('on'),2200);
  });
})();

/* let's talk: pill expands into a contact dropdown */
(function(){
  const cta=document.getElementById('cta'), panel=document.getElementById('ctaPanel'), btn=document.getElementById('ctaBtn');
  if(!cta||!panel||!btn) return;
  const ghost=cta.querySelector('.cta-ghost'), list=panel.querySelector('.cta-list');
  let open=false;
  const closedSize=()=>({w:ghost.offsetWidth,h:ghost.offsetHeight});
  function set(o){
    open=o; const c=closedSize();
    panel.classList.toggle('open',o); btn.setAttribute('aria-expanded',o);
    panel.style.width=(o?Math.max(256,c.w):c.w)+'px';
    panel.style.height=(o?c.h+list.scrollHeight+10:c.h)+'px';
  }
  const init=()=>{const c=closedSize(); panel.style.width=c.w+'px'; panel.style.height=c.h+'px';};
  init(); addEventListener('load',init); addEventListener('resize',()=>set(false));
  btn.addEventListener('click',e=>{e.stopPropagation(); set(!open);});
  const xb=document.getElementById('ctaX'); if(xb) xb.addEventListener('click',e=>{e.stopPropagation(); set(false);});
  panel.addEventListener('click',e=>{ if(e.target.closest('.cta-list a')) setTimeout(()=>set(false),150); });
  document.addEventListener('click',e=>{ if(open&&!cta.contains(e.target)) set(false); });
  addEventListener('keydown',e=>{ if(e.key==='Escape'&&open){ set(false); btn.focus(); } });
})();
